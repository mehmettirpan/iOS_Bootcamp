This application  basic contacts app same image but this is not contacts app

TR- Bu kodlama derisnde kullanılan fonksiyonların başlıcaları şunlardır;

EN- The main functions used in this coding leather are;

* viewdidload
* willappear
* performseque
* identifier
* basic core data but not use coredata or any online database
* delete operating
* searchBar
* StackView
* ScroolView
